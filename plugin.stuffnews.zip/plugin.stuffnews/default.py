import xbmcgui
import xbmcplugin
import requests
from bs4 import BeautifulSoup

# Set the URL of the Stuff News RSS feed
STUFF_RSS_URL = 'https://www.stuff.co.nz/rss/'

# Define the plugin handle
HANDLE = int(sys.argv[1])

def fetch_stories():
    # Fetch the RSS feed from Stuff News
    r = requests.get(STUFF_RSS_URL)
    if r.status_code == 200:
        # Parse the RSS feed using BeautifulSoup
        soup = BeautifulSoup(r.content, 'xml')
        # Get the list of news stories
        stories = soup.find_all('item')
        # Return the list of stories
        return stories
    else:
        # If the request fails, display an error message
        xbmcgui.Dialog().ok('Error', 'Failed to fetch news stories')
        return []

def display_stories():
    # Fetch the list of news stories
    stories = fetch_stories()
    # Create a list item for each story
    for story in stories:
        # Get the title, description, and link for the story
        title = story.title.text
        description = story.description.text
        link = story.link.text
        # Create a list item with the title and description
        list_item = xbmcgui.ListItem(label=title, label2=description)
        # Set the list item's URL to the story's link
        list_item.setInfo('video', {'title': title, 'plot': description})
        list_item.setProperty('IsPlayable', 'true')
        list_item.setPath(link)
        # Add the list item to the Kodi plugin
        xbmcplugin.addDirectoryItem(HANDLE, link, list_item, False)
    # End the Kodi plugin's directory list
    xbmcplugin.endOfDirectory(HANDLE)

# Start the Kodi plugin
xbmcplugin.setContent(HANDLE, 'videos')
display_stories()
